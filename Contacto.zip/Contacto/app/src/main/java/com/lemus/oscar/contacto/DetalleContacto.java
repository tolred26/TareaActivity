package com.lemus.oscar.contacto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetalleContacto extends AppCompatActivity {

    TextView txtNombre, txtTelefono, txtEmail, txtDescripcion, txtFecha;
    Button btnRegresar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_contacto);

        txtNombre = (TextView) findViewById(R.id.txtNombre);
        txtFecha= (TextView) findViewById(R.id.txtFecha);
        txtTelefono= (TextView) findViewById(R.id.txtTelefono);
        txtEmail= (TextView) findViewById(R.id.txtEmail);
        txtDescripcion = (TextView) findViewById(R.id.txtDescripcion);
        btnRegresar = (Button)findViewById(R.id.btnRegresar);

        Bundle parametros = getIntent().getExtras();

        if (parametros == null) {
            finish();
        }

        txtNombre.setText(parametros.getString(getResources().getString(R.string.pNombre)));
        txtFecha.setText(parametros.getString(getResources().getString(R.string.pFecNac)));
        txtTelefono.setText(parametros.getString(getResources().getString(R.string.pTelefono)));
        txtEmail.setText(parametros.getString(getResources().getString(R.string.pEmail)));
        txtDescripcion.setText(parametros.getString(getResources().getString(R.string.pDesc)));


        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
