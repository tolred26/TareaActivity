package com.lemus.oscar.contacto;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatePicker datePicker;
    TextView txtNombre, txtTelefono, txtEmail, txtDescripcion;
    Button btnEnviar;
    TextInputLayout til_nombre, til_Telefono, til_Email, til_Desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        datePicker = (DatePicker) findViewById(R.id.dpFechaNacimiento);
        txtNombre = (TextView) findViewById(R.id.txtNombre);
        txtTelefono= (TextView) findViewById(R.id.txtTelefono);
        txtEmail= (TextView) findViewById(R.id.txtEmail);
        txtDescripcion = (TextView) findViewById(R.id.txtDescripcion);


        til_nombre = (TextInputLayout) findViewById(R.id.til_nombre);
        til_Telefono= (TextInputLayout) findViewById(R.id.til_Telefono);
        til_Email = (TextInputLayout) findViewById(R.id.til_Email);
        til_Desc = (TextInputLayout) findViewById(R.id.til_Desc);


        btnEnviar= (Button)findViewById(R.id.btnEnviar);
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidarDatos();
            }
        });
    }


    private void ValidarDatos() {
        if (!validarNombre()) {
            return;
        }

        if (!validarEmail()) {
            return;
        }

        if (!validarTelefono()) {
            return;
        }

        if (!validarDescripcion()) {
            return;
        }

        Intent intent = new Intent(MainActivity.this,DetalleContacto.class);
        intent.putExtra(getResources().getString(R.string.pNombre), txtNombre.getText().toString());
        intent.putExtra(getResources().getString(R.string.pTelefono), txtTelefono.getText().toString());
        intent.putExtra(getResources().getString(R.string.pEmail), txtEmail.getText().toString());
        intent.putExtra(getResources().getString(R.string.pDesc), txtDescripcion.getText().toString());

        String fecha = String.valueOf(datePicker.getDayOfMonth() + "-" +
                        String.valueOf(datePicker.getMonth() + 1 + "-" +
                                        String.valueOf(datePicker.getYear())
                        )
        );

        intent.putExtra(getResources().getString(R.string.pFecNac), fecha);

        startActivity(intent);
    }

    private boolean validarNombre() {
        if (txtNombre.getText().toString().trim().isEmpty()) {
            til_nombre.setError(getString(R.string.err_msg_nombre));
            requestFocus(txtNombre);
            return false;
        } else {
            til_nombre.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validarTelefono() {
        if (txtTelefono.getText().toString().trim().isEmpty()) {
            til_Telefono.setError(getString(R.string.err_msg_tel));
            requestFocus(txtTelefono);
            return false;
        } else {
            til_Telefono.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validarDescripcion() {
        if (txtDescripcion.getText().toString().trim().isEmpty()) {
            til_Desc.setError(getString(R.string.err_msg_desc));
            requestFocus(txtDescripcion);
            return false;
        } else {
            til_Desc.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validarEmail() {
        String email = txtEmail.getText().toString().trim();

        if (email.isEmpty() || !emailValido(email)) {
            til_Email.setError(getString(R.string.err_msg_email));
            requestFocus(txtEmail);
            return false;
        } else {
            til_Email.setErrorEnabled(false);
        }

        return true;
    }

    private static boolean emailValido(String email) {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }


}
